#include <iostream>
using namespace std;

//(i)
//int main(void) {
//	char a = 'a';
//	char b = 'b';
//
//	while (a < b) {
//		cout << "malyalam is a palindrome" << endl;
//		a++;
//	}
//	return 0;
//}

//(j)
//int main(void) {
//	int i = 10;
//
//	while (i == 20) {
//		cout << "A computer buff" << endl;
//	}
//	return 0;
//}

//(k)
int main(void) {
	int i = 10;

	while (i == 10) {
		cout << i << endl;
		i = i + 1;
	}
	return 0;
}