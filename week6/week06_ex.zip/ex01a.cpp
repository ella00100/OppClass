#include <iostream>
using namespace std;

void display();

int main() {
	cout << "\nOnly stupids use C?" << endl;
	display();
	return 0;
}

void display() {
	cout << "\nFools too use C!" << endl;
	main();
}