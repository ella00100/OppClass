#include <iostream>
using namespace std;

// (c)

//int main(void)
//{
//	int j = 1;
//	while (j <= 10) {
//		cout << j << endl;
//		j = j+1 ;
//	}
//	return 0;
//}

// (d)

//int main(void)
//{
//	int x = 1;
//	while (x == 1) {
//		x = x - 1;
//		cout << x << endl;
//	}
//	return 0;
//}

//(e)
int main(void)
{
	int x = 1;
	while (x == 1) 
		x = x - 1;
	cout << x << endl;
	return 0;
}