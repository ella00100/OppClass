#include <iostream>
using namespace std;

int main() {
	cout << "\nC to it that C survives" << endl;
	main();
	return 0;
}