#include <iostream>
using namespace std;

// (a)

//int main(void)
//{
//	int j = 1;
//	while (j <= 10) {
//		cout << j << endl;
//		j = j+1 ;
//	}
//	return 0;
//}


//(b) 


int main(void)
{
	int j = 1;
	while (j <= 10) {
		cout << j << endl;
		j++;
	}
	return 0;
}
