#include <iostream>
using namespace std;

void message();

int main() {
	message();

	return 0;
}

void message(void) {
	cout << "\nPraise worthy and C worthy are synonyms" << endl;
}