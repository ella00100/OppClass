#include <iostream>
using namespace std;

void message(void);

int main() {
	message();
	return 0;
}

void message(void) {
	cout << "\nViruses are written in C" << endl;
}